/***********************************************************************************************/
/*                                                                                             */
/*                                      File : RandomLaws.cpp                                  */
/*                                                                                             */
/*                                                                                             */
/*                                                             2007                            */
/*                                                             Benoit ROCK                     */
/*                                                                                             */
/***********************************************************************************************/


#include "Rand48.h"
#include <time.h>
#include <math.h>

#define PI 3.14159265358979323846264338327950288419716939937510582


// Nombres aleatoires uniformes sur l'intervale [0,1[ ---------------------------
static bool first = true;
double RandNbrUniform ()
{
	if(first)
	{
		srand48((long)time(NULL));
		first = false;
	}
	return drand48 ();
}


// Nombres aleatoires uniformes sur l'intervalle [a,b[ --------------------------

double RandNbrUniformAB (double borneA, double borneB)
{
	double U;

	U = RandNbrUniform ();
	return U * (borneB - borneA) + borneA;
}

// Nombres aleatoires uniformes sur l'intervalle [a,b] --------------------------

int RandNbrUniformIntAB (int borneA, int borneB)
{
	double U;

	U = RandNbrUniform ();
	return int(floor (U * (borneB - borneA + 1) + borneA));
}


// Nombres aleatoires de loi triangulaire --------------------------------------

double RandNbrTriangular (double a, double b)
{
	double U, T;

	U = RandNbrUniform ();
	if (U <= (a / (a + b)))
		T = double(sqrt (a * (a + b) * U) - a);
	else
		T = double(-sqrt (b * (a + b) * (1 - U)) + b);

	return T;
}

// Nombres aleatoires de loi triangulaire fonction retounant aussi le Nb unif associe------

double RandNbrTriangular (double a, double b, double &U)
{
	double T;

	U = RandNbrUniform ();
	if (U <= (a / (a + b)))
		T = double(sqrt (a * (a + b) * U) - a);
	else
		T = double(-sqrt (b * (a + b) * (1 - U)) + b);

	return T;
}


// Nombres aleatoires de la loi Poisonnienne ----------------------------------

int RandNbrPoisson (double lambda)
{
	double U = 1;
	int P = 0;

	while (U >= exp (-lambda))
	{
		U *= RandNbrUniform ();
		P++;
	}

	return P - 1;
}


// Nombres aleatoires de la loi Normale sans parametres ------------------------

double RandNbrNormal ()
{
	double U = 0;
	int n = 10; // dans cet algorithme, on peut prendre 6<=n<=12

	for (int i = 0; i < n; i++)
	{
		U += RandNbrUniform ();
	}

	return (U - n / 2) / sqrt (n / 12.0);
}


// Nombres aleatoires de la loi Normale avec parametres ------------------------

double RandNbrNormalMS (double moy, double sigma)
{
	double R;

	R = RandNbrNormal ();

	return moy + R * sigma;
}


// Nombres aleatoires Loi de Bernouilli ----------------------------------------

int RandNbrBernouilli (double p)
{
	double inter = RandNbrUniform ();

	if (inter < p)
		return 1;
	else
		return 0;
}


// Nombres aleatoires de loi Binomiale -----------------------------------------

int RandNbrBinomial (int n, double p)
{
	int B = 0;

	if (n < 30) // cas n "petit"
	{
		for (int i = 0; i <= n; i++)
		{
			if (RandNbrUniform () < p)
				B++;
		}
	}
	else    // cas n "grand"
	{
		if ((n * p) < 5.0)
			B = RandNbrPoisson (n * p);
		else
			B = int(RandNbrNormalMS (n * p, n * p * (1 - p)));
	}
	return B;
}


// Nombres aleatoires de loi Geometrique --------------------------------------

int RandNbrGeometric (double p)
{
	int k = 1;
	double U;

	U = RandNbrUniform ();
	while (U >= (1 - pow (1 - p, k)))
	{
		k++;
	}
	return k - 1;
}


// Nombres aleatoires de loi Exponentielle --------------------------------------------

double RandNbrExponential (double lambda)
{
	double U;

	U = RandNbrUniform ();

	return -log (U) / lambda;
}


// Nombres aleatoires de loi Hyperexponentielle ---------------------------------------

double RandNbrHyperexponential (double lambda1, double lambda2, double proba)
{
	if (RandNbrBernouilli (proba))
		return RandNbrExponential (lambda1);
	else
		return RandNbrExponential (lambda2);
}


// Nombres aleatoires de loi d'Erlang --------------------------------------------------

double RandNbrErlang (double lambda, int k)
{
	double tmp = 1.0;

	for (int i = 0; i < k; i++)
	{
		tmp *= RandNbrUniform ();
	}

	return -log (tmp) / lambda;
}

// Nombres aleatoires de loi Log-Normale ---------------------------------------------

double RandNbrLogNormal (double moy_log, double sigma_log)
{
	return exp (RandNbrNormalMS (moy_log, sigma_log));
}


// Nombres aleatoires de la loi de Rayleigh -------------------------------------------

double RandNbrRayleigh (double sigma)
{
	return sigma * (sqrt (-2 * log (RandNbrUniform ())));
}


// Nombres aleatoires de loi Gamma ----------------------------------------------------

double RandNbrGamma (double lambda, double alpha)
{
	int k;
	double frac;

	k = int(alpha);
	frac = fmod (alpha, 1);
	if (RandNbrBernouilli (frac))
		return RandNbrErlang (lambda, k + 1);
	else
		return RandNbrErlang (lambda, k);
}


double RandNbrCauchy()
{
	return tan((double)PI * RandNbrUniform());
}

double RandNbrStandardLogistic()
{
	double u;

	do
	{
		u = RandNbrUniform();
	}while((u == 0.0) ||(u == 1.0));

	return -log(u/(1.0-u));
}

double sgn(double val)
{
	if(val >=0)
		return 1.0;
	else
		return -1.0;
}

void RandNbrCartesianMarsaglia(double &x1,double &x2)
{
	double W, V1, V2, Q;
	do
	{
		double U1 = RandNbrUniform ();
		double U2 = RandNbrUniform ();
		V1 = 2.0 * U1 - 1.0;
		V2 = 2.0 * U2 - 1.0;
		W = V1 * V1 + V2 * V2;
	}while((W > 1) || (W == 0.0));
	/*Apres cette etape, V1 et V2 ont ete tires de maniere uniforme sur [-1;1] tels que 0<V2�+V1�<=1*/
	Q = sqrt(-2.0 * log(W) / W);
	x1 = V1 * Q;
	x2 = V2 * Q;
}

void RandNbrPolarMarsaglia(double &x1,double &x2)
{
	double u /*in ]0,1[*/, R, Angle;
	do
	{
		u = RandNbrUniform();
	}while(u == 0.0);

	R = sqrt(-2.0 * log(u));
	Angle = 2.0 * (double)PI * RandNbrUniform();

	x1 =  R * cos(Angle);
	x2 =  R * sin(Angle);
}

double RandNbrGaussian(double mean, double stdDev)
{
	static bool hasSpare = false;
	static double spare;

	if(hasSpare)
	{
		hasSpare = false;
		return mean + stdDev * spare;
	}
	hasSpare = true;

	double u, v, s;

	do
	{
		u = RandNbrUniform() * 2.0 - 1.0;
		v = RandNbrUniform() * 2.0 - 1.0;
		s = u * u + v * v;
	}
	while( (s >= 1.0) || (s == 0.0) );

	s = sqrt(-2.0 * log(s) / s);
	spare = v * s;

	return mean + stdDev * u * s;
}

