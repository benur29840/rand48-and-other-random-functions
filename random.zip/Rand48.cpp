/***********************************************************************************************/
/*                                                                                             */
/*                                      File : Rand48.cpp                                      */
/*                                                                                             */
/*        random UNIX functions (stdlib.h) implementation for WINDOWS                          */
/*                                                                                             */
/*                                                             2007                            */
/*                                                             Benoit ROCK                     */
/*                                                                                             */
/***********************************************************************************************/

#ifdef _WIN32

#include "Rand48.h"
#include <stdarg.h>
#include <math.h>

struct int48
{
	unsigned short bit[4];
};

int48 egal(unsigned short count, unsigned short x0, ...)
{
	int48 ret;
	unsigned short j;

	for(j=0; j<3; j++)
	{
		ret.bit[j] = 0;
	}
	va_list  lste;
#ifndef __GNUC__
	va_start (lste, count);

	ret.bit[0] = (unsigned short int) va_arg (lste, int);
#else
	va_start (lste, x0);

	ret.bit[0] = x0;

#endif
	ret.bit[1] = (unsigned short int) va_arg (lste, int);
	ret.bit[2] = (unsigned short int) va_arg (lste, int);

	va_end (lste);

	return ret;
}

int48 add(int48 val1 , int48 val2)
{
	int48 ret;
	unsigned long sum = 0;
	for (unsigned long j= 0; j<4; j++)
	{
		sum += (unsigned long)val1.bit[j] + (unsigned long)val2.bit[j];
		ret.bit[j] = (unsigned short)sum;
		sum >>= 16;
	}

	return ret;
}

int48 mult(int48 val1, int48 val2)
{
	int48 ret = egal(3, 0, 0, 0);
	unsigned long ll, sum = 0;
	for(unsigned long j=0; j<3; j++)
	{
		for(unsigned long l=0; l<4; l++)
		{
			ll = j+l;
			sum += (unsigned long)val1.bit[j] * (unsigned long)val2.bit[l];
			sum += ret.bit[ll];
			ret.bit[ll] = (unsigned short)sum;
			sum >>= 16;
			if(ll == 3 )
				break;
		}
		sum = 0;
	}

	return ret;
}


// a = 0x05DEECE66D, c = 0x0B;
int48 default_a = egal(3, 0xE66D, 0xDEEC, 0x05),  default_c = egal(3, 0x0B,0 ,0);
int48 Xn;
int48 a = default_a;
int48 c = default_c;


//Xn+1 = (aXn + c)mod m   n>= 0
int48 Xn_next(int48 X, int48 a, int48 c)
{
	int48 ret = add(mult(a,X), c);
	return ret;
}

//The appropriate number of bits, according to the type of data item to be returned, are copied
//from the high-order (leftmost) bits of Xi and transformed into the returned value.
long int int48ToLong(int48 X)
{
	long ret = 0;

	ret = X.bit[2];
	ret <<= 16;
	ret += X.bit[1];

	return ret;
}

double int48ToDouble(int48 X)
{
	double ret = 0.0;

	ret = (double)X.bit[0] + ((double)X.bit[1])*pow((double)2.0, 16) + ((double)X.bit[2])*pow((double)2.0, 32);

	return ret;
}


double edrand48(int48 X)
{
	double ret = 0.0;

	Xn = Xn_next(X, a, c);
	ret = int48ToDouble(Xn);
	ret /= (double)0xFFFFFFFFFFFF;

	if(ret < 0)
		ret = -ret;

	return ret;
}

//The drand48() function returns non-negative, double-precision,
//floating-point values, uniformly distributed over the interval [0.0 , 1.0].
double drand48(void)
{
	return edrand48(Xn);
}

//The erand48() function returns non-negative, double-precision,
//floating-point values, uniformly distributed over the interval [0.0 , 1.0].
double erand48(unsigned short int xsubi[3])
{
	return edrand48( egal(3,xsubi[0], xsubi[1], xsubi[2]));
}

long int lnrand48(int48 X)
{
	long ret = 0;
	unsigned long reti = 0;
	Xn = Xn_next(X, a, c);
	reti = int48ToLong(Xn);
	reti /= 2;
	ret = reti;
	if(ret < 0)
		ret = -ret;
	ret = ret;
	return ret;
}

//The lrand48() function returns non-negative, long integers,
//uniformly distributed over the interval [0,2**31[.
long int lrand48(void)
{
	return lnrand48(Xn);
}

//The nrand48() function returns non-negative, long integers,
//uniformly distributed over the interval [0,2**31[.
long int nrand48(unsigned short int xsubi[3])
{
	return lnrand48(egal(3, xsubi[0], xsubi[1], xsubi[2]));
}

long int mjrand48(int48 X)
{
	long ret = 0;
	Xn = Xn_next(X, a, c);
	ret = int48ToLong(Xn);
	return ret;
}

//The mrand48() function return signed long integers uniformly distributed over
// the interval [-2**31,2**31[.
long int mrand48(void)
{
	return mjrand48(Xn);
}

//The jrand48() function returns signed long integers uniformly distributed over
// the interval [-2**31,2**31[.
long int jrand48(unsigned short int xsubi[3])
{
	return mjrand48(egal(3, xsubi[0], xsubi[1], xsubi[2]));
}


//initialisation entry points
//sets 48 bits of Xi to the 48 bits contained in its argument.
static unsigned short int Xi[3];
unsigned short int* seed48(unsigned short int seed16v[3])
{
	unsigned short int b =0;

	for(int j=0; j<3; j++)
	{
		Xi[j] = Xn.bit[j];
	}

	Xn = egal(3, seed16v[0], seed16v[1], seed16v[2]);

	a = default_a;

	c = default_c;

	return Xi;
}

//initialisation entry points
//sets the high-order 32 bits of Xi to the low-order 32 bits contained in its argument.
// The low-order 16 bits of Xi are set to the arbitrary value 0x330E .
void srand48(long int seedval)
{
	unsigned short int X[3];

	X[0] = 0x330E;
	X[1] = (unsigned short int)seedval;
	X[2] = (unsigned short int)(seedval >> 16);///Pow(2,16));

	Xn = egal(3, X[0], X[1], X[2]);

	a = default_a;

	c = default_c;

}

//initialisation entry points
void lcong48(unsigned short int param[7])
{
	Xn = egal(3, param[0], param[1], param[2]);

	a = egal(3, param[3], param[4], param[5]);

	c = egal(3, param[6], 0, 0);
}

#endif //_WIN32