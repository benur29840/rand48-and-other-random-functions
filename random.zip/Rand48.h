/***********************************************************************************************/
/*                                                                                             */
/*                                      File : Rand48.h                                        */
/*                                                                                             */
/*        random UNIX functions (stdlib.h) implementation for WINDOWS                          */
/*                                                                                             */
/*                                                                                             */
/***********************************************************************************************/
/**
 * Copyright (C) 2016 Benoit Rock
 *                    rock.s.architecture.free.fr/random.html
 *
 * Rock's Architecture is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _RAND48_H__
#define _RAND48_H__

#ifndef _WIN32 //Unix | linux | apple
#include <stdlib.h>
#else

//The drand48() function returns non-negative, double-precision,
//floating-point values, uniformly distributed over the interval [0.0 , 1.0].
double drand48(void);

//The erand48() function returns non-negative, double-precision,
//floating-point values, uniformly distributed over the interval [0.0 , 1.0].
//sets 48 bits of Xi to the 48 bits contained in its arguments.
double erand48(unsigned short int xsubi[3]);

//The jrand48() function return signed long integers uniformly distributed over
// the interval [-2**31,2**31[.
//sets 48 bits of Xi to the 48 bits contained in its arguments.
long int jrand48(unsigned short int xsubi[3]);

//initialisation entry points
//sets 48 bits of Xi to the 48 bits contained in its 3 first arguments.
//sets 48 bits of a to the 48 bits contained in its 3 next arguments.
//sets low-order 48 bits of c to the 16 bits contained in its last argument.
void lcong48(unsigned short int param[7]);

//The lrand48() function returns non-negative, long integers,
//uniformly distributed over the interval [0,2**31[.
long int lrand48(void);

//The mrand48() function return signed long integers uniformly distributed over
// the interval [-2**31,2**31[.
long int mrand48(void);

//The nrand48() function returns non-negative, long integers,
//uniformly distributed over the interval [0,2**31[.
//sets 48 bits of Xi to the 48 bits contained in its arguments.
long int nrand48(unsigned short int xsubi[3]);

//initialisation entry points
//sets 48 bits of Xi to the 48 bits contained in its arguments.
unsigned short int* seed48(unsigned short int seed16v[3]);

//initialisation entry points
//sets the high-order 48 bits of Xi to the low-order 48 bits contained in its argument.
// The low-order 16 bits of Xi are set to the arbitrary value 0x330E .
void srand48(long int seedval);

#endif //_WIN32
#endif //_RAND48_H__
